$( document ).ready(function() {
    var connection;

    $('#btnConectar').on('click', function(){
       
        $(this).css('display', 'none');
        $('.spinner-border').css('display', 'block');
        
        connection = new WebSocket('wss://e3qoxbvsjf.execute-api.us-east-1.amazonaws.com/dev/');
        connection.onopen = function (event) {
            var msg = {"action":"sendMessage", "data":"solicitar"};
            connection.send(JSON.stringify(msg));
        };

        connection.onerror = function (error) {
          console.log('WebSocket Error ' + error);
        };
        connection.onmessage = function (e) {


            if(e.data === "aceptar"){
                
                $('.spinner-border').css('display', 'none');
                $('#myModal').modal('show');
                
            }else if(e.data === "rechazar"){
                
                $('.spinner-border').css('display', 'none');
                $('#myModal2').modal('show');
                
            }
                
//                var msg = {"action":"sendMessage", "data":"solicitar"};
//                connection.send(JSON.stringify(msg));
                
            
                
                
                
//                if(confirm(e.data)){
//                    $('#myModal').modal('show');
////                    var msg = {"action":"sendMessage", "data":"confirmo"};
////                    connection.send(JSON.stringify(msg));
//                    console.log('confirmo');
//                }else{
//                    $('#myModal2').modal('show');
////                    var msg = {"action":"sendMessage", "data":"rechazo"};
////                    connection.send(JSON.stringify(msg));
//                    console.log('rechazo');
//                }
            

        };

    }); 
//    $('#btnDesconectar').on('click', function(){
//        $(this).css('display', 'none');
//        $('#btnConectar').css('display', 'block');
//        connection.close();
//        console.log('Se desconecto');
//    });
    $('#myModal').on('show.bs.modal', function () {
        var mod = $('.modal');
        $('.insidemodal').html(mod);
    });
    $('#myModal2').on('show.bs.modal', function () {
        var mod = $('.modal');
        $('.insidemodal').html(mod);
    });
    $('#myModal').on('hidden.bs.modal', function () {
        connection.close();
        $('#btnConectar').css('display', 'block');
        console.log('1');
    });
    $('#myModal2').on('hidden.bs.modal', function () {
        connection.close();
        $('#btnConectar').css('display', 'block');
        console.log('2');
    });
});